package com.example.first_flutter_vs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
